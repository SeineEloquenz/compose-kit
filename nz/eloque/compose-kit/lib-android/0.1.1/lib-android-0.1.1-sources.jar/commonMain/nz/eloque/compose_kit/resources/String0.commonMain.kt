@file:OptIn(InternalResourceApi::class)

package nz.eloque.compose_kit.resources

import kotlin.OptIn
import kotlin.String
import kotlin.collections.MutableMap
import org.jetbrains.compose.resources.InternalResourceApi
import org.jetbrains.compose.resources.LanguageQualifier
import org.jetbrains.compose.resources.RegionQualifier
import org.jetbrains.compose.resources.ResourceContentHash
import org.jetbrains.compose.resources.ResourceItem
import org.jetbrains.compose.resources.StringResource

private const val MD: String = "composeResources/nz.eloque.compose_kit.resources/"

@delegate:ResourceContentHash(1_442_936_864)
public val Res.string.compose_kit_about: StringResource by lazy {
      StringResource("string:compose_kit_about", "compose_kit_about", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 10, 33),
        ResourceItem(setOf(LanguageQualifier("ca"), ), "${MD}values-ca/strings.commonMain.cvr", 10, 41),
        ResourceItem(setOf(LanguageQualifier("cs"), ), "${MD}values-cs/strings.commonMain.cvr", 10, 41),
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 10, 33),
        ResourceItem(setOf(LanguageQualifier("el"), ), "${MD}values-el/strings.commonMain.cvr", 10, 53),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 10, 37),
        ResourceItem(setOf(LanguageQualifier("et"), ), "${MD}values-et/strings.commonMain.cvr", 10, 45),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 10, 37),
        ResourceItem(setOf(LanguageQualifier("gl"), ), "${MD}values-gl/strings.commonMain.cvr", 10, 33),
        ResourceItem(setOf(LanguageQualifier("it"), ), "${MD}values-it/strings.commonMain.cvr", 10, 41),
        ResourceItem(setOf(LanguageQualifier("iw"), ), "${MD}values-iw/strings.commonMain.cvr", 10, 41),
        ResourceItem(setOf(LanguageQualifier("lt"), ), "${MD}values-lt/strings.commonMain.cvr", 10, 33),
        ResourceItem(setOf(LanguageQualifier("lv"), ), "${MD}values-lv/strings.commonMain.cvr", 10, 41),
        ResourceItem(setOf(LanguageQualifier("nl"), ), "${MD}values-nl/strings.commonMain.cvr", 10, 33),
        ResourceItem(setOf(LanguageQualifier("pl"), ), "${MD}values-pl/strings.commonMain.cvr", 10, 41),
        ResourceItem(setOf(LanguageQualifier("pt"), RegionQualifier("BR"), ), "${MD}values-pt-rBR/strings.commonMain.cvr", 10, 33),
        ResourceItem(setOf(LanguageQualifier("pt"), ), "${MD}values-pt/strings.commonMain.cvr", 10, 33),
        ResourceItem(setOf(LanguageQualifier("ru"), ), "${MD}values-ru/strings.commonMain.cvr", 10, 57),
        ResourceItem(setOf(LanguageQualifier("sv"), ), "${MD}values-sv/strings.commonMain.cvr", 10, 29),
        ResourceItem(setOf(LanguageQualifier("tr"), ), "${MD}values-tr/strings.commonMain.cvr", 10, 37),
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("CN"), ), "${MD}values-zh-rCN/strings.commonMain.cvr", 10, 33),
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("TW"), ), "${MD}values-zh-rTW/strings.commonMain.cvr", 10, 33),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 10, 33),
      ))
    }

@delegate:ResourceContentHash(1_728_849_618)
public val Res.string.compose_kit_choose_image: StringResource by lazy {
      StringResource("string:compose_kit_choose_image", "compose_kit_choose_image", setOf(
        ResourceItem(setOf(LanguageQualifier("ca"), ), "${MD}values-ca/strings.commonMain.cvr", 52, 48),
        ResourceItem(setOf(LanguageQualifier("cs"), ), "${MD}values-cs/strings.commonMain.cvr", 52, 52),
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 44, 52),
        ResourceItem(setOf(LanguageQualifier("el"), ), "${MD}values-el/strings.commonMain.cvr", 64, 72),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 48, 56),
        ResourceItem(setOf(LanguageQualifier("et"), ), "${MD}values-et/strings.commonMain.cvr", 56, 44),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 48, 56),
        ResourceItem(setOf(LanguageQualifier("gl"), ), "${MD}values-gl/strings.commonMain.cvr", 44, 56),
        ResourceItem(setOf(LanguageQualifier("it"), ), "${MD}values-it/strings.commonMain.cvr", 52, 52),
        ResourceItem(setOf(LanguageQualifier("iw"), ), "${MD}values-iw/strings.commonMain.cvr", 52, 56),
        ResourceItem(setOf(LanguageQualifier("lt"), ), "${MD}values-lt/strings.commonMain.cvr", 44, 56),
        ResourceItem(setOf(LanguageQualifier("nl"), ), "${MD}values-nl/strings.commonMain.cvr", 44, 56),
        ResourceItem(setOf(LanguageQualifier("pt"), RegionQualifier("BR"), ), "${MD}values-pt-rBR/strings.commonMain.cvr", 44, 52),
        ResourceItem(setOf(LanguageQualifier("ru"), ), "${MD}values-ru/strings.commonMain.cvr", 68, 84),
        ResourceItem(setOf(LanguageQualifier("sv"), ), "${MD}values-sv/strings.commonMain.cvr", 40, 48),
        ResourceItem(setOf(LanguageQualifier("tr"), ), "${MD}values-tr/strings.commonMain.cvr", 48, 48),
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("CN"), ), "${MD}values-zh-rCN/strings.commonMain.cvr", 44, 48),
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("TW"), ), "${MD}values-zh-rTW/strings.commonMain.cvr", 44, 48),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 44, 48),
      ))
    }

@delegate:ResourceContentHash(125_250_903)
public val Res.string.compose_kit_clear_selection: StringResource by lazy {
      StringResource("string:compose_kit_clear_selection", "compose_kit_clear_selection", setOf(
        ResourceItem(setOf(LanguageQualifier("ca"), ), "${MD}values-ca/strings.commonMain.cvr", 101, 63),
        ResourceItem(setOf(LanguageQualifier("cs"), ), "${MD}values-cs/strings.commonMain.cvr", 105, 55),
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 97, 55),
        ResourceItem(setOf(LanguageQualifier("el"), ), "${MD}values-el/strings.commonMain.cvr", 137, 87),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 105, 63),
        ResourceItem(setOf(LanguageQualifier("et"), ), "${MD}values-et/strings.commonMain.cvr", 101, 55),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 105, 63),
        ResourceItem(setOf(LanguageQualifier("gl"), ), "${MD}values-gl/strings.commonMain.cvr", 101, 59),
        ResourceItem(setOf(LanguageQualifier("it"), ), "${MD}values-it/strings.commonMain.cvr", 105, 59),
        ResourceItem(setOf(LanguageQualifier("iw"), ), "${MD}values-iw/strings.commonMain.cvr", 109, 59),
        ResourceItem(setOf(LanguageQualifier("lt"), ), "${MD}values-lt/strings.commonMain.cvr", 101, 63),
        ResourceItem(setOf(LanguageQualifier("nl"), ), "${MD}values-nl/strings.commonMain.cvr", 101, 55),
        ResourceItem(setOf(LanguageQualifier("pt"), RegionQualifier("BR"), ), "${MD}values-pt-rBR/strings.commonMain.cvr", 97, 59),
        ResourceItem(setOf(LanguageQualifier("ru"), ), "${MD}values-ru/strings.commonMain.cvr", 153, 71),
        ResourceItem(setOf(LanguageQualifier("sv"), ), "${MD}values-sv/strings.commonMain.cvr", 89, 51),
        ResourceItem(setOf(LanguageQualifier("tr"), ), "${MD}values-tr/strings.commonMain.cvr", 97, 55),
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("CN"), ), "${MD}values-zh-rCN/strings.commonMain.cvr", 93, 51),
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("TW"), ), "${MD}values-zh-rTW/strings.commonMain.cvr", 93, 51),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 93, 55),
      ))
    }

@delegate:ResourceContentHash(1_118_420_428)
public val Res.string.compose_kit_delete: StringResource by lazy {
      StringResource("string:compose_kit_delete", "compose_kit_delete", setOf(
        ResourceItem(setOf(LanguageQualifier("ca"), ), "${MD}values-ca/strings.commonMain.cvr", 165, 38),
        ResourceItem(setOf(LanguageQualifier("cs"), ), "${MD}values-cs/strings.commonMain.cvr", 161, 38),
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 153, 38),
        ResourceItem(setOf(LanguageQualifier("el"), ), "${MD}values-el/strings.commonMain.cvr", 225, 50),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 169, 38),
        ResourceItem(setOf(LanguageQualifier("et"), ), "${MD}values-et/strings.commonMain.cvr", 157, 38),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 169, 38),
        ResourceItem(setOf(LanguageQualifier("gl"), ), "${MD}values-gl/strings.commonMain.cvr", 161, 38),
        ResourceItem(setOf(LanguageQualifier("it"), ), "${MD}values-it/strings.commonMain.cvr", 165, 38),
        ResourceItem(setOf(LanguageQualifier("iw"), ), "${MD}values-iw/strings.commonMain.cvr", 169, 42),
        ResourceItem(setOf(LanguageQualifier("lt"), ), "${MD}values-lt/strings.commonMain.cvr", 165, 38),
        ResourceItem(setOf(LanguageQualifier("lv"), ), "${MD}values-lv/strings.commonMain.cvr", 52, 34),
        ResourceItem(setOf(LanguageQualifier("nl"), ), "${MD}values-nl/strings.commonMain.cvr", 157, 42),
        ResourceItem(setOf(LanguageQualifier("pl"), ), "${MD}values-pl/strings.commonMain.cvr", 52, 34),
        ResourceItem(setOf(LanguageQualifier("pt"), RegionQualifier("BR"), ), "${MD}values-pt-rBR/strings.commonMain.cvr", 157, 38),
        ResourceItem(setOf(LanguageQualifier("ru"), ), "${MD}values-ru/strings.commonMain.cvr", 225, 46),
        ResourceItem(setOf(LanguageQualifier("sv"), ), "${MD}values-sv/strings.commonMain.cvr", 141, 38),
        ResourceItem(setOf(LanguageQualifier("tr"), ), "${MD}values-tr/strings.commonMain.cvr", 153, 30),
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("CN"), ), "${MD}values-zh-rCN/strings.commonMain.cvr", 145, 34),
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("TW"), ), "${MD}values-zh-rTW/strings.commonMain.cvr", 145, 34),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 149, 34),
      ))
    }

@delegate:ResourceContentHash(1_778_697_574)
public val Res.string.compose_kit_image: StringResource by lazy {
      StringResource("string:compose_kit_image", "compose_kit_image", setOf(
        ResourceItem(setOf(LanguageQualifier("ca"), ), "${MD}values-ca/strings.commonMain.cvr", 204, 33),
        ResourceItem(setOf(LanguageQualifier("cs"), ), "${MD}values-cs/strings.commonMain.cvr", 200, 37),
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 192, 33),
        ResourceItem(setOf(LanguageQualifier("el"), ), "${MD}values-el/strings.commonMain.cvr", 276, 41),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 208, 33),
        ResourceItem(setOf(LanguageQualifier("et"), ), "${MD}values-et/strings.commonMain.cvr", 196, 33),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 208, 33),
        ResourceItem(setOf(LanguageQualifier("gl"), ), "${MD}values-gl/strings.commonMain.cvr", 200, 33),
        ResourceItem(setOf(LanguageQualifier("it"), ), "${MD}values-it/strings.commonMain.cvr", 204, 37),
        ResourceItem(setOf(LanguageQualifier("iw"), ), "${MD}values-iw/strings.commonMain.cvr", 212, 41),
        ResourceItem(setOf(LanguageQualifier("lt"), ), "${MD}values-lt/strings.commonMain.cvr", 204, 37),
        ResourceItem(setOf(LanguageQualifier("lv"), ), "${MD}values-lv/strings.commonMain.cvr", 87, 37),
        ResourceItem(setOf(LanguageQualifier("nl"), ), "${MD}values-nl/strings.commonMain.cvr", 200, 33),
        ResourceItem(setOf(LanguageQualifier("pl"), ), "${MD}values-pl/strings.commonMain.cvr", 87, 33),
        ResourceItem(setOf(LanguageQualifier("pt"), RegionQualifier("BR"), ), "${MD}values-pt-rBR/strings.commonMain.cvr", 196, 33),
        ResourceItem(setOf(LanguageQualifier("pt"), ), "${MD}values-pt/strings.commonMain.cvr", 44, 33),
        ResourceItem(setOf(LanguageQualifier("ru"), ), "${MD}values-ru/strings.commonMain.cvr", 272, 57),
        ResourceItem(setOf(LanguageQualifier("sv"), ), "${MD}values-sv/strings.commonMain.cvr", 180, 33),
        ResourceItem(setOf(LanguageQualifier("tr"), ), "${MD}values-tr/strings.commonMain.cvr", 184, 37),
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("CN"), ), "${MD}values-zh-rCN/strings.commonMain.cvr", 180, 33),
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("TW"), ), "${MD}values-zh-rTW/strings.commonMain.cvr", 180, 33),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 184, 33),
      ))
    }

@delegate:ResourceContentHash(404_853_414)
public val Res.string.compose_kit_invalid_input: StringResource by lazy {
      StringResource("string:compose_kit_invalid_input", "compose_kit_invalid_input", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 218, 53),
      ))
    }

@delegate:ResourceContentHash(-1_231_055_166)
public val Res.string.compose_kit_more_options: StringResource by lazy {
      StringResource("string:compose_kit_more_options", "compose_kit_more_options", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 44, 68),
        ResourceItem(setOf(LanguageQualifier("ca"), ), "${MD}values-ca/strings.commonMain.cvr", 238, 48),
        ResourceItem(setOf(LanguageQualifier("cs"), ), "${MD}values-cs/strings.commonMain.cvr", 238, 56),
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 226, 52),
        ResourceItem(setOf(LanguageQualifier("el"), ), "${MD}values-el/strings.commonMain.cvr", 318, 88),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 242, 52),
        ResourceItem(setOf(LanguageQualifier("et"), ), "${MD}values-et/strings.commonMain.cvr", 230, 48),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 242, 52),
        ResourceItem(setOf(LanguageQualifier("gl"), ), "${MD}values-gl/strings.commonMain.cvr", 234, 52),
        ResourceItem(setOf(LanguageQualifier("it"), ), "${MD}values-it/strings.commonMain.cvr", 242, 52),
        ResourceItem(setOf(LanguageQualifier("iw"), ), "${MD}values-iw/strings.commonMain.cvr", 254, 72),
        ResourceItem(setOf(LanguageQualifier("lt"), ), "${MD}values-lt/strings.commonMain.cvr", 242, 60),
        ResourceItem(setOf(LanguageQualifier("lv"), ), "${MD}values-lv/strings.commonMain.cvr", 125, 60),
        ResourceItem(setOf(LanguageQualifier("nl"), ), "${MD}values-nl/strings.commonMain.cvr", 234, 48),
        ResourceItem(setOf(LanguageQualifier("pl"), ), "${MD}values-pl/strings.commonMain.cvr", 121, 52),
        ResourceItem(setOf(LanguageQualifier("pt"), RegionQualifier("BR"), ), "${MD}values-pt-rBR/strings.commonMain.cvr", 230, 52),
        ResourceItem(setOf(LanguageQualifier("pt"), ), "${MD}values-pt/strings.commonMain.cvr", 78, 52),
        ResourceItem(setOf(LanguageQualifier("ru"), ), "${MD}values-ru/strings.commonMain.cvr", 330, 72),
        ResourceItem(setOf(LanguageQualifier("sv"), ), "${MD}values-sv/strings.commonMain.cvr", 214, 52),
        ResourceItem(setOf(LanguageQualifier("tr"), ), "${MD}values-tr/strings.commonMain.cvr", 222, 60),
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("CN"), ), "${MD}values-zh-rCN/strings.commonMain.cvr", 214, 48),
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("TW"), ), "${MD}values-zh-rTW/strings.commonMain.cvr", 214, 48),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 272, 48),
      ))
    }

@delegate:ResourceContentHash(-2_058_906_949)
public val Res.string.compose_kit_search: StringResource by lazy {
      StringResource("string:compose_kit_search", "compose_kit_search", setOf(
        ResourceItem(setOf(LanguageQualifier("ca"), ), "${MD}values-ca/strings.commonMain.cvr", 287, 34),
        ResourceItem(setOf(LanguageQualifier("cs"), ), "${MD}values-cs/strings.commonMain.cvr", 295, 34),
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 279, 34),
        ResourceItem(setOf(LanguageQualifier("el"), ), "${MD}values-el/strings.commonMain.cvr", 407, 50),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 295, 34),
        ResourceItem(setOf(LanguageQualifier("et"), ), "${MD}values-et/strings.commonMain.cvr", 279, 34),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 295, 42),
        ResourceItem(setOf(LanguageQualifier("gl"), ), "${MD}values-gl/strings.commonMain.cvr", 287, 34),
        ResourceItem(setOf(LanguageQualifier("it"), ), "${MD}values-it/strings.commonMain.cvr", 295, 34),
        ResourceItem(setOf(LanguageQualifier("iw"), ), "${MD}values-iw/strings.commonMain.cvr", 327, 42),
        ResourceItem(setOf(LanguageQualifier("lt"), ), "${MD}values-lt/strings.commonMain.cvr", 303, 38),
        ResourceItem(setOf(LanguageQualifier("lv"), ), "${MD}values-lv/strings.commonMain.cvr", 186, 38),
        ResourceItem(setOf(LanguageQualifier("nl"), ), "${MD}values-nl/strings.commonMain.cvr", 283, 34),
        ResourceItem(setOf(LanguageQualifier("pl"), ), "${MD}values-pl/strings.commonMain.cvr", 174, 34),
        ResourceItem(setOf(LanguageQualifier("pt"), RegionQualifier("BR"), ), "${MD}values-pt-rBR/strings.commonMain.cvr", 283, 38),
        ResourceItem(setOf(LanguageQualifier("ru"), ), "${MD}values-ru/strings.commonMain.cvr", 403, 42),
        ResourceItem(setOf(LanguageQualifier("sv"), ), "${MD}values-sv/strings.commonMain.cvr", 267, 34),
        ResourceItem(setOf(LanguageQualifier("tr"), ), "${MD}values-tr/strings.commonMain.cvr", 283, 30),
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("CN"), ), "${MD}values-zh-rCN/strings.commonMain.cvr", 263, 34),
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("TW"), ), "${MD}values-zh-rTW/strings.commonMain.cvr", 263, 34),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 321, 34),
      ))
    }

@delegate:ResourceContentHash(401_076_451)
public val Res.string.compose_kit_selected: StringResource by lazy {
      StringResource("string:compose_kit_selected", "compose_kit_selected", setOf(
        ResourceItem(setOf(LanguageQualifier("ca"), ), "${MD}values-ca/strings.commonMain.cvr", 322, 44),
        ResourceItem(setOf(LanguageQualifier("cs"), ), "${MD}values-cs/strings.commonMain.cvr", 330, 40),
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 314, 44),
        ResourceItem(setOf(LanguageQualifier("el"), ), "${MD}values-el/strings.commonMain.cvr", 458, 56),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 330, 44),
        ResourceItem(setOf(LanguageQualifier("et"), ), "${MD}values-et/strings.commonMain.cvr", 314, 40),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 338, 48),
        ResourceItem(setOf(LanguageQualifier("gl"), ), "${MD}values-gl/strings.commonMain.cvr", 322, 44),
        ResourceItem(setOf(LanguageQualifier("it"), ), "${MD}values-it/strings.commonMain.cvr", 330, 44),
        ResourceItem(setOf(LanguageQualifier("iw"), ), "${MD}values-iw/strings.commonMain.cvr", 370, 40),
        ResourceItem(setOf(LanguageQualifier("lv"), ), "${MD}values-lv/strings.commonMain.cvr", 225, 44),
        ResourceItem(setOf(LanguageQualifier("nl"), ), "${MD}values-nl/strings.commonMain.cvr", 318, 44),
        ResourceItem(setOf(LanguageQualifier("pl"), ), "${MD}values-pl/strings.commonMain.cvr", 209, 44),
        ResourceItem(setOf(LanguageQualifier("pt"), RegionQualifier("BR"), ), "${MD}values-pt-rBR/strings.commonMain.cvr", 322, 44),
        ResourceItem(setOf(LanguageQualifier("ru"), ), "${MD}values-ru/strings.commonMain.cvr", 446, 48),
        ResourceItem(setOf(LanguageQualifier("sv"), ), "${MD}values-sv/strings.commonMain.cvr", 302, 40),
        ResourceItem(setOf(LanguageQualifier("tr"), ), "${MD}values-tr/strings.commonMain.cvr", 314, 40),
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("CN"), ), "${MD}values-zh-rCN/strings.commonMain.cvr", 298, 40),
        ResourceItem(setOf(LanguageQualifier("zh"), RegionQualifier("TW"), ), "${MD}values-zh-rTW/strings.commonMain.cvr", 298, 40),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 356, 40),
      ))
    }

@InternalResourceApi
internal fun _collectCommonMainString0Resources(map: MutableMap<String, StringResource>) {
  map.put("compose_kit_about", Res.string.compose_kit_about)
  map.put("compose_kit_choose_image", Res.string.compose_kit_choose_image)
  map.put("compose_kit_clear_selection", Res.string.compose_kit_clear_selection)
  map.put("compose_kit_delete", Res.string.compose_kit_delete)
  map.put("compose_kit_image", Res.string.compose_kit_image)
  map.put("compose_kit_invalid_input", Res.string.compose_kit_invalid_input)
  map.put("compose_kit_more_options", Res.string.compose_kit_more_options)
  map.put("compose_kit_search", Res.string.compose_kit_search)
  map.put("compose_kit_selected", Res.string.compose_kit_selected)
}
