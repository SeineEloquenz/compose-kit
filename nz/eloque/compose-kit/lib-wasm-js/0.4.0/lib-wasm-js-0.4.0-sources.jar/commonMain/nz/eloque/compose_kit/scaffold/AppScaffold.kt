package nz.eloque.compose_kit.scaffold

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.TopAppBarScrollBehavior
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * [Scaffold] with a collapse-on-scroll [TopAppBar], a navigation-bar-aware FAB
 * slot, a snackbar host, and status-bar insets handled for the caller.
 *
 * [content] receives the [TopAppBarScrollBehavior] so a scrollable child can drive the
 * collapsing top bar via `Modifier.nestedScroll(scrollBehavior.nestedScrollConnection)`.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppScaffold(
    modifier: Modifier = Modifier,
    title: @Composable () -> Unit = {},
    navigationIcon: @Composable () -> Unit = {},
    actions: @Composable RowScope.() -> Unit = {},
    subRow: (@Composable RowScope.() -> Unit)? = null,
    floatingActionButton: @Composable () -> Unit = {},
    bottomBar: @Composable () -> Unit = {},
    snackbarHostState: SnackbarHostState = remember { SnackbarHostState() },
    contentHorizontalPadding: Dp = 16.dp,
    content: @Composable (scrollBehavior: TopAppBarScrollBehavior) -> Unit,
) {
    val scrollBehavior = TopAppBarDefaults.exitUntilCollapsedScrollBehavior()
    Scaffold(
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        topBar = {
            TopAppBar(
                navigationIcon = navigationIcon,
                title = title,
                actions = actions,
                scrollBehavior = scrollBehavior,
            )
            subRow?.let { Row { it() } }
        },
        contentWindowInsets = WindowInsets.statusBars,
        bottomBar = bottomBar,
        floatingActionButton = {
            Box(
                modifier =
                    Modifier.padding(
                        bottom =
                            WindowInsets.navigationBars
                                .asPaddingValues()
                                .calculateBottomPadding(),
                    ),
            ) {
                floatingActionButton()
            }
        },
    ) { innerPadding ->
        Box(
            modifier =
                modifier
                    .padding(innerPadding)
                    .padding(horizontal = contentHorizontalPadding),
        ) {
            content(scrollBehavior)
        }
    }
}
